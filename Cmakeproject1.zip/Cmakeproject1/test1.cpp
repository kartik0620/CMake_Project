#include "project.h"
#include "fmt/format.h"
#include "fmt/core.h"


struct point {
double x, y;
};


template <>
struct fmt::formatter<point> : nested_formatter<double> {
 auto format(point p, format_context& ctx) const {
  return write_padded(ctx, [=](auto out) {
   return format_to(out, "({}, {})", this->nested(p.x),
     this->nested(p.y));
   });
 }
};