#include<iostream>
#include<fmt/format.h>
#include<fmt/core.h>


int main()
{

fmt::println("[{:>20.2f}]", point{1, 2});

}